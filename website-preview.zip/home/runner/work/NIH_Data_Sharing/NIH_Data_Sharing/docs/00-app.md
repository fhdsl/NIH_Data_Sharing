
# DMS Helper App {-}


The Fred Hutch Data Science Lab has created and online app where you can create your NIH Data Management and Sharing Plan. It includes template text corresponding to different Fred Hutch Research Cores. You can download your filled-in plan in either Word or Markdown format.

https://dmshelper.fredhutch.org/

<img src="00-app_files/figure-html//1luFoDzF6aDJEebbL6iWoJ_s8s9nQnaWLL5jghbmWdak_g21c2a6e60cf_39_0.png" title="Preview of the DMS Helper App." alt="Preview of the DMS Helper App." width="100%" style="display: block; margin: auto;" />
